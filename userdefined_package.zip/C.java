package abc;
import Mncs.*;

class C
{
    public static void main(String[] args) {
        Amazon amazon = new Amazon();
        Apple apple = new Apple();
        Accenture accenture = new Accenture();

        // Accessing methods of Amazon class
        System.out.println("Amazon:\n");
        amazon.founder_and_ceo();
        amazon.services();
        amazon.revenue();
        System.out.println();

        // Accessing methods of Apple class
        System.out.println("Apple:\n");
        apple.founder_and_ceo();
        apple.services();
        apple.revenue();
        System.out.println();

        // Accessing methods of Accenture class
        System.out.println("Accenture:\n");
        accenture.founder_and_ceo();
        accenture.services();
        accenture.revenue();
    }
}