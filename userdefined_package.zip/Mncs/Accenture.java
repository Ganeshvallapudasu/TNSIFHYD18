package Mncs;
public class Accenture
{
	public	void founder_and_ceo()
	{
		System.out.println("founder : Arthur Andersen");
        System.out.println("CEO     : Julie Sweet\n");
	}
	public void services()
	{
		System.out.println("SERVICES :");
		System.out.println("Cybersecurity and risk management\n");
	}
	public void revenue() {
		System.out.println("REVENUE :");
		System.out.println("2023 = $64.11 billion");
		System.out.println("2022 = $61.59 billion");
		System.out.println("2020 = 	$60.59 billion");
		
	}
}



