package Mncs;
	
	
public class Amazon {
		
		public void founder_and_ceo()
		{
			System.out.println("Founder : jeff Bezos");
			System.out.println(" CEO    : Andy jassy\n");
		}
			
		public void services()
		{
			System.out.println(" Services :\n"
					+ "Amazon.com\nAmazon Appstore\nAmazon Music\r\n"
					+ "Amazon Pay\r\n"
					+ "Amazon Prime video \n One Medical\r\n"
					+ "Twitch\r\n"
					+ "Ring\r\n"
					+ "Amazon Web Services\r\n"
					+ "Amazon Robotics\n");
					
					
				
			
		}
	 
		public void revenue()
		{
		System.out.println("REVENUE :");
	     System.out.println("2023 revenue = $574.785B");
		 System.out.println("2022 revenue = $513.983B");
		 System.out.println("2021 revenue = $469.822B\n");
		}
	}
