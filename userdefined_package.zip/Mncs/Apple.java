package Mncs;
public class Apple

{
	public void founder_and_ceo()
	{
		System.out.println("founder : Steve Jobs, Steve Wozniak and Ronald Wayne");
		System.out.println("CEO     : Timothy Donald Cook\n");
	}
	public void services()
	{
		System.out.println("SERVICES :");
		System.out.println("Apple Music\nApple News\nApple Fitness\n");
	}
	public void revenue()
	{
		System.out.println("REVENUE :");
		System.out.println("2023 = $383.285B");
		System.out.println("2022 = $382B");
		System.out.println("2020 = 	$378.32B\n");
	}
}